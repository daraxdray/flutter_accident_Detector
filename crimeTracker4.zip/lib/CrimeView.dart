import 'dart:io';

import 'package:crimetracker/crimeList.dart';
import 'package:crimetracker/editCrime.dart';
import 'package:crimetracker/main.dart';
import 'package:crimetracker/model/crime.dart';
import 'package:crimetracker/repository/db_provider.dart';
import 'package:crimetracker/repository/EngineRoom.dart';
import 'package:crimetracker/utils/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:search_map_place/search_map_place.dart';
import 'package:image_picker/image_picker.dart';

class CrimePage extends StatelessWidget {
 final Crime crime;

  const CrimePage({Key? key, required this.crime}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
      body: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: CrimeView(crime:crime),
      )
    );
  }
}

class CrimeView extends StatefulWidget {
  final Crime crime;

   CrimeView({Key? key, required this.crime}) : super(key: key);

  @override
  _CrimeViewState createState() => _CrimeViewState();
}

class _CrimeViewState extends State<CrimeView> {
  String currentImage = "";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    currentImage = widget.crime.img;
  }

  @override
  Widget build(BuildContext context) {
    Crime crime = widget.crime;


print(currentImage != null);
    return Container(
        margin: EdgeInsets.only(top: 20),
        child: Column(
            children: [
              Container(
                alignment: Alignment.center,
                height: 300,
                child: CircleAvatar(
                    radius: 200,
                    child: currentImage != null? Image.file(File(currentImage)) : Image.asset('assets/calling.jpg'),
                    )
              ),
              Container(
                margin: EdgeInsets.only(top:50),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [

                        Container(
                            height: 100,
                            width: 100,
                            child: InkWell(
                              child:  crime.img != null? Image.file(File(crime.img)) : Image.asset('assets/calling.jpg'),
                              onTap: ()=>{
                                setState(() {
                                  currentImage = crime.img;
                                })
                              },
                            )
                        ),
                        Container(
                            height: 100,
                            width: 100,
                            child: InkWell(
                              child: crime.img2 != null? Image.file(File(crime.img2)) : Image.asset('assets/calling.jpg'),
                              onTap: ()=>{
                                setState(() {
                                  currentImage = crime.img2;
                                })
                              },
                            )
                        ),
                        Container(
                            height: 100,
                            width: 100,
                            child: InkWell(
                              child: crime.img3 != null ? Image.file(File(crime.img3)) : Image.asset('assets/calling.jpg'),
                              onTap: ()=>{
                                setState(() {
                                  currentImage = crime.img3;
                                })
                              },
                            )
                        ),

                      ]
                  )
              ),
              Container(
                  margin: EdgeInsets.only(top:20),
                  child: Text("${crime.crimeType}",style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold
                  ),)),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("Crime Location:  ")
                    ),
                    Container(child: Text("${crime.cLocation}",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("State:  ")
                    ),
                    Container(child: Text("${crime.cState}",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("Description:  ")
                    ),
                    Container(child: Text("${crime.cDescription}",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("Date:  ")
                    ),
                    Container(child: Text("${DateTime.parse(crime.date)}",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("Progress Note:  ")
                    ),
                    Container(child: Text("${crime.progressNote} ",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                child: Row(
                  children: [
                    Container(
                        child: Text("Reported By:  ")
                    ),
                    Container(child: Text("${crime.reportedBy} ",style: TextStyle(
                        fontSize: 13,
                        color: Colors.black26
                    ),)),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(10),
                alignment: Alignment.center,
                child: Row(
                  children: [
                    Container(
                        child: TextButton(
                          onPressed: ()=> Navigator.push(context, MaterialPageRoute(builder:(context) => EditCrimePage(crime: crime))),
                        child: Text('Edit'),)
                    ),
                    Container(
                        child: TextButton(
                          onPressed: (){
                            DbProvider.db.deletecrime(crime.id).then((value) => Navigator.push(context, MaterialPageRoute(builder:(context) => CrimeListView())));
                          },
                        child: Text('Delete'),)
                    ),
                  ],
                ),
              ),

            ]
        )
    );
  }
}

