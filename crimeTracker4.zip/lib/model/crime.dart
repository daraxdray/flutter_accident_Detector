
class Crime {
  int id;
  String crimeType;
  String cDescription;
  String cLocation;
  String cState;
  String cLga;
  String? reportedBy;
  String? reporterLocation;
  String? progressNote;
  String? cCode;
  String img;
  String img2;
  String img3;
  String date;

  Crime({ required this.id,
  required this.crimeType,
  required this.cDescription,
  required this.cLocation,
  required this.cState,
  required this.cLga,
  this.reportedBy,
  this.reporterLocation,
  this.cCode,
  this.progressNote,
  required this.img,
  required this.img2,
  required this.img3,
  required this.date,
});

  factory Crime.fromMap(Map<dynamic,dynamic> data) => new Crime(
    id: data['crimeTypeId'],
    crimeType : data['crimeType'],
    cDescription : data['crimeDescription'],
    cLocation : data['crimeLocation'],
    cState : data['crimeState'],
    reportedBy : data['reportedBy'],
    reporterLocation : data['reporterLocation'],
    img : data['img'],
    img2 : data['img2'],
    img3 : data['img3'],
    date : data['dateCreated'],
    cLga: data['crimeLga'],
    progressNote: data['progressNote'],
    cCode: data['crimeCode'],
  );

 factory Crime.fromDb(Map<dynamic,dynamic> data) => new Crime(id: data['crimeTypeId'],
    crimeType : data['crimeType'],
    cDescription : data['crimeType'],
    cLocation : data['crimeLocation'],
    cState : data['crimeState'],
    progressNote: data['progressNote'],
    reportedBy: data['reportedBy'],
     reporterLocation: data['reporterLocation'],
    cCode: data['crimeCode'],
    img : data['eImg'],
    img2 : data['eImg2'],
    img3 : data['eImg3'],
    date : data['dateCreated'],
     cLga: data['crimeLga']
  );

  Map <String,dynamic> toDb(){
    var map = <String, Object> {
    'crimeType' : this.crimeType,
    'crimeDescription' : this.cDescription,
    'crimeLocation' : this.cLocation,
    'crimeState' : this.cState,
    'crimeLga' : this.cLga,
      'crimeCode':this.cCode ?? "",
    'eImg' : this.img,
    'eImg2' : this.img2,
    'eImg3' : this.img3,
    'dateCreated': this.date,
    'reporterLocation': this.reporterLocation ?? "",
    'reportedBy': this.reportedBy ?? "",
    'progressNote':this.progressNote ?? ""
    };
    return map;
  }
  // crimeTypeId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,crimeType TEXT NOT NULL,crimcrimeType TEXT NOT NULL,crimcLocation TEXT NOT NULL,crimeState TEXT NOT NULL,crimeLga TEXT NOT NULL,reportedBy TEXT NOT NULL,progressNote TEXT NULL,crimeCode TEXT NULL, eImg TEXT NULL,eImg2 TEXT NULL,eImg3 TEXT NULL,dateCreated TEXT NOT NULL

}