// @dart=2.9

import 'package:crimetracker/CrimeView.dart';
import 'package:crimetracker/crimeList.dart';
import 'package:crimetracker/first_page.dart';
import 'package:crimetracker/login_page.dart';
import 'package:crimetracker/model/crime.dart';
import 'package:crimetracker/model/user.dart';
import 'package:crimetracker/repository/db_provider.dart';
import 'package:flutter/material.dart';
import 'package:crimetracker/addCrime.dart';
import 'package:flutter/foundation.dart'
  show debugDefaultTargetPlatformOverride;
void main() {
  debugDefaultTargetPlatformOverride = TargetPlatform.fuchsia;
  runApp(MyApp());
}

class MyApp extends StatelessWidget {


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Crime Report',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        body: HomePage(),
      )
    );
  }
}


class HomePage extends StatelessWidget {
   HomePage({key}) : super(key: key);
 TextEditingController passCode = TextEditingController();
 TextEditingController crimeCode = TextEditingController();


   Widget showAlert(context,type) {
     Widget enterPasscode = AlertDialog(
       title: Text("Admin PassCode"),
       content: SizedBox(
         height: 200,
         child: Column(
             mainAxisAlignment: MainAxisAlignment.start,
             children: [
               Container(
                   margin: const EdgeInsets.all(10),
                   alignment: Alignment.centerLeft,
                   child: Text(
                       "Enter Passcode", style: TextStyle(color: Colors.black))
               ),
               Container(
                   height: 50,
                   width: MediaQuery
                       .of(context)
                       .size
                       .width * 0.7,
                   margin: EdgeInsets.only(bottom: 15, right: 10),
                   padding: EdgeInsets.only(bottom: 10),
                   decoration: BoxDecoration(
                       color: Colors.grey[200],
                       borderRadius:
                       BorderRadius.all(Radius.circular(12))),
                   child: TextFormField(
                     enabled: true,
                     controller: passCode,
                     validator: (string) {
                       if (string == "") return "Please enter admin passcode";
                       return null;
                     },
                     style: TextStyle(color: Colors.black,),
                     decoration: InputDecoration(
                         labelText: "Passcode",
                         labelStyle: TextStyle(color: Colors.black26),
                         fillColor: Colors.black26),
                   )),
             ]
         ),
       ),
       actions: [
         TextButton(
             onPressed: () => Navigator.pop(context), child: Text("cancel")),
         TextButton(onPressed: () {
           if (passCode.text != "PassAdmin123") {
             ScaffoldMessenger.of(context).showSnackBar(SnackBar(
               content: Text("Incorrect Passcode"),
               backgroundColor: Colors.green,));
             return;
           }
           Navigator.push(context,
               MaterialPageRoute(builder: (context) => CrimeListView()));
         }, child: Text("Proceed")),

       ],
     );
     Widget enterTrackCode = AlertDialog(
       title: Text("Crime Track ID"),
       content: SizedBox(
         height: 200,
         child: Column(
             mainAxisAlignment: MainAxisAlignment.start,
             children: [
               Container(
                   margin: const EdgeInsets.all(10),
                   alignment: Alignment.centerLeft,
                   child: Text(
                       "Enter Crime Code", style: TextStyle(color: Colors.black))
               ),
               Container(
                   height: 50,
                   width: MediaQuery
                       .of(context)
                       .size
                       .width * 0.7,
                   margin: EdgeInsets.only(bottom: 15, right: 10),
                   padding: EdgeInsets.only(bottom: 10),
                   decoration: BoxDecoration(
                       color: Colors.grey[200],
                       borderRadius:
                       BorderRadius.all(Radius.circular(12))),
                   child: TextFormField(
                     enabled: true,
                     controller: crimeCode,
                     validator: (string) {
                       if (string == "") return "Please enter crime code";
                       return null;
                     },
                     style: TextStyle(color: Colors.black,),
                     decoration: InputDecoration(
                         labelText: "Crime Tracking Code",
                         labelStyle: TextStyle(color: Colors.black26),
                         fillColor: Colors.black26),
                   )),
             ]
         ),
       ),
       actions: [
         TextButton(
             onPressed: () => Navigator.pop(context), child: Text("Cancel")),
         TextButton(onPressed: () async {
           if (crimeCode.text == "") {
             ScaffoldMessenger.of(context).showSnackBar(SnackBar(
               content: Text("Empty Crime Record Code entered"),
               backgroundColor: Colors.green,));
             return;
           }
           Crime crime =  await DbProvider.db.getCrimeByCode(code:crimeCode.text);
           if(crime != null){
             Navigator.push(context,
                 MaterialPageRoute(builder: (context) => CrimePage(crime: crime,)));
             return;
           }else{

             ScaffoldMessenger.of(context).showSnackBar(SnackBar(
               content: Text("No Records Found"),
               backgroundColor: Colors.red,));
           }

         }, child: Text("Proceed")),

       ],
     );
     showDialog(context: context, builder: (b) {
       if(type == 'admin'){
       return enterPasscode;
       }else{
         return enterTrackCode;
       }
     },);
   }


   @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            margin: EdgeInsets.all(50),
              child:
              Column(
                children: [
                  Container(
                    alignment: Alignment.center,
                    child: Text("Welcome to Crime Report", style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold
                    ),),
                  ),
                  Container(
                      height: 150,
                      width: 300,
                      child: Image( image: AssetImage('assets/police.png'))
                  ),
                  Text("Add New Crime"),
                  ElevatedButton(onPressed: ()=>
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> AddCrimePage())), child: Icon(Icons.add)),

                ],
              )
          ),
        Container(
          child:
          Flex(
            direction: Axis.horizontal,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(onPressed: ()=> showAlert(context,'admin'), child: Text("Admin")),
              ElevatedButton(onPressed: ()=>
              Navigator.push(context, MaterialPageRoute(builder: (context)=> FirstPage())), child: Text("Register")),
              User.isLoggedIn()?
              ElevatedButton(onPressed: ()=>
              Navigator.push(context, MaterialPageRoute(builder: (context)=> CrimeListView(listBy:User.getUserEmail()))), child: Text("My Reports")):
              ElevatedButton(onPressed: ()=>
              Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage())), child: Text("Login")),
              ElevatedButton(onPressed: ()=>
                  showAlert(context,'crimeId'), child: Text("Track Record")),

            ],
          ),
        )
        ],
      )
    ),

    );
  }



}
