import 'dart:developer';
import 'dart:io';
import 'package:crimetracker/model/crime.dart';
import 'package:crimetracker/model/user.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbProvider {
  DbProvider._();
  static final DbProvider db = DbProvider._();
  static const String crimeTable = "CRIME";
  static String userTable = "USER";
  static var _database;
  static var databasePath;
  Future<Database> get database async {
    _database = null;
    if(_database != null){
      return _database;
    }

    _database = await initDB();
    return _database;
  }


  initDB() async {
      databasePath = await getDatabasesPath();
      var path =  join(databasePath,'crime_db');
      // await deleteDatabase(path);
      _database = await openDatabase(
          path,
          version: 1,
          onCreate: (Database db,int version) => _createDb(db),
      );

      return _database;
    }

    static void _createDb(Database db){
      db.execute("CREATE TABLE $crimeTable ( crimeTypeId INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,crimeType TEXT NOT NULL,crimeDescription TEXT NOT NULL,crimeLocation TEXT NOT NULL,crimeState TEXT NOT NULL, crimeLga TEXT NOT NULL,reportedBy TEXT NOT NULL,progressNote TEXT NULL,reporterLocation TEXT NULL,crimeCode TEXT NULL, eImg TEXT NULL,eImg2 TEXT NULL,eImg3 TEXT NULL,dateCreated TEXT NOT NULL)" );
      db.execute("CREATE TABLE $userTable ( uid INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,uName TEXT NOT NULL,uPhone TEXT NOT NULL,uAddress TEXT NOT NULL,uPassword TEXT NOT NULL,uEmail TEXT NOT NULL,dateCreated TEXT NOT NULL)");
    }

  Future<dynamic> insertDb(dynamic data, {table: crimeTable}) async {
    Database db = await database;
    data.id = await db.insert(table,data.toDb());
    // print(data);
    return data;
  }


  Future<List<Crime>> getAllCrimes() async {
    Database db = await database;

    List<Map> result;
    result = await db.query(crimeTable);
    print(result);
    List<Crime> cr = result.isNotEmpty? result.map((e) => Crime.fromDb(e)).toList():[];
    return cr;
  }


   getCrimeById({id:0}) async  {
    Database db = await database;
    List<Map> result;
    if(id == 0){
      return  null;
    }else
    {
      result = await db.query(crimeTable,
          where: 'id = $id',
          whereArgs: [id]);
      if(result.length >0 ){

        return  Crime.fromDb(result.first);
      }
    }



  }

  Future<Crime?> getCrimeByCode({code:""}) async  {
    Database db = await database;
    List<Map> result;
    if(code == ""){
      return  null;
    }else
    {
      result = await db.query(crimeTable,
          where: 'crimeCode = ?',
          whereArgs: [code]
      );

      if(result.length >0 ){
        return  Crime.fromDb(result.first);
      }
      return null;
    }



  }

  Future<List<Crime>> getCrimesByKey({key}) async  {
    Database db = await database;
    List<Map> result;
    if(key == ""){
      return  [];
    }else
    {
      result = await db.query(crimeTable,
          where: 'reportedBy = ? OR crimeCode = ?',
          whereArgs: [key,key]);
      print(result);

      List<Crime> cr = result.isNotEmpty? result.map((e) => Crime.fromDb(e)).toList():[];
      return cr;
    }



  }

  getUserByEmail({email ="",password =""}) async  {
    Database db = await database;
    List<Map> result;
    if(email == ""){
      return  null;
    }else
    {
      // var res = await db.rawQuery("SELECT * FROM $userTable");
      // print(res);
      result = await db.query(userTable,
          where: 'uEmail = ? AND uPassword = ?',
          whereArgs: [email,password]);
      if(result.isNotEmpty ){
        return  User.fromDb(result.first);
      }
      return null;
    }



  }


  Future<int> deletecrime(id) async {
    Database db = await database;
    return await  db.delete(crimeTable,where: 'crimeTypeId == $id',whereArgs: [id]);
  }

  Future update(Crime crime) async {
    Database db = await database;
    var update = await db.update(crimeTable, crime.toDb(),where: 'crimeTypeId == ?', whereArgs: [crime.id] );
    print(update);
  }

  Future close() async => db.close();


}

