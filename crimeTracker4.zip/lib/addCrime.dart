import 'dart:io';
import 'dart:math';

import 'package:clipboard/clipboard.dart';
import 'package:crimetracker/main.dart';
import 'package:crimetracker/model/crime.dart';
import 'package:crimetracker/model/user.dart';
import 'package:crimetracker/repository/db_provider.dart';
import 'package:crimetracker/repository/EngineRoom.dart';
import 'package:crimetracker/utils/constant.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// import 'package:search_map_place/search_map_place.dart';
import 'package:image_picker/image_picker.dart';

class AddCrimePage extends StatelessWidget {
  final User? user;
  const AddCrimePage({Key? key, this.user}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Add New Crime"),),
      body: SingleChildScrollView(
        physics: ScrollPhysics(),
        child: Container(
          margin: EdgeInsets.only(top: 20),
            child: Column(

                children: [
            Text("${user?.name ?? ""}",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20),),
                  SizedBox(height: 20,),
                  Center( child: Text("You can add new Crime")),
                  SizedBox(height: 20,),
                  CrimeForm()
                ]
            )
        ),
      )
    );
  }
}


class CrimeForm extends StatefulWidget {
  final User? user;
  const CrimeForm({key, this.user}) : super(key: key);

  @override
  _CrimeFormState createState() => _CrimeFormState();
}

class _CrimeFormState extends State<CrimeForm> {
  GlobalKey<FormState> formKey = GlobalKey();
  final ImagePicker _picker = ImagePicker();
  bool _autoValidate = false;
  bool processing = false;
  bool locprocessing = false;
  String crimeCode = "";
  TextEditingController crimeType = TextEditingController();
  TextEditingController crimeDesc = TextEditingController();
  String _stateLoc = "";
  TextEditingController location = TextEditingController();
  TextEditingController currentLocation = TextEditingController();
  TextEditingController lga = TextEditingController();
  File _image = File('');
  File _image2 = File('');
  File _image3 = File('');
  Random _rand = Random();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _autoValidate = false;
    processing = false;
    crimeCode = User.isLoggedIn()?"":"Cr0_"+ _rand.nextInt(9999).toString();
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Form(
          key: formKey,
            autovalidateMode: AutovalidateMode.always,
            child: Column(
              children: [
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.9,
                    margin: EdgeInsets.only(bottom: 15,right: 10),
                    padding: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius:
                        BorderRadius.all(Radius.circular(12))),
                    child: TextFormField(
                      enabled: true,
                      controller: crimeType,
                      validator: (string){
                        if(string == "") return "Could be rape, robbery or others";
                        return null;
                      }
                      ,
                      style: TextStyle(color: Colors.black,),
                      decoration: InputDecoration(
                          labelText: " Crime Type",
                          labelStyle: TextStyle(color: Colors.black26,),
                          fillColor: Colors.white,

                      ),
                    )),

                // Container(
                //     height: 50,
                //     width: MediaQuery.of(context).size.width * 0.7,
                //     margin: EdgeInsets.only(bottom: 15,right: 10),
                //     padding: EdgeInsets.only(bottom: 10),
                //     decoration: BoxDecoration(
                //         color: Colors.grey[200],
                //         borderRadius:
                //         BorderRadius.all(Radius.circular(12))),
                //     child: TextFormField(
                //       enabled: true,
                //       validator: (string){
                //         if(string == "") return "Please describe crime location";
                //         return null;
                //       },
                //       controller: location,
                //       style: TextStyle(color: Colors.black),
                //       decoration: InputDecoration(
                //           labelText: "Crime Location",
                //           labelStyle: TextStyle(color: Colors.black26),
                //           fillColor: Colors.white),
                //     )),

                Container(
                    margin: const EdgeInsets.all(10),
                    alignment : Alignment.centerLeft,
                    width: MediaQuery.of(context).size.width * 0.9,
                    child:
                    DropdownButtonFormField<String>(
                      items: ['Select state','Lagos','Abuja','Niger State','Osun','Imo'].map((String category) {
                        return  DropdownMenuItem(
                            value: category,
                            child: Row(
                              children: <Widget>[
                                Text(category)
                              ],
                            )
                        );
                      }).toList(),
                      onChanged: ( String? newValue) {
                        // do other stuff with _category
                        setState(() => _stateLoc = newValue ?? "");
                      },
                      value: 'Select state',
                      validator: (val){
                        if(val != null){
                          return null;
                        }
                        return "Please select bank";
                      },
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.fromLTRB(10, 20, 10, 20),
                        border: OutlineInputBorder(borderSide: const BorderSide(color:Colors.black12,),borderRadius: BorderRadius.circular(10),),
                        filled: true,
                        fillColor: Colors.white,
                        hintText: "Select State",
                      ),
                    )),
                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.9,
                    margin: EdgeInsets.only(bottom: 15,right: 10),
                    padding: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius:
                        BorderRadius.all(Radius.circular(12))),
                    child: TextFormField(
                      enabled: true,
                      controller: lga,
                      style: TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                          labelText: "Location LGA",

                          labelStyle: TextStyle(color: Colors.black26),
                          fillColor: Colors.black),
                    )),

                Container(
                    height: 50,
                    width: MediaQuery.of(context).size.width * 0.9,
                    margin: EdgeInsets.only(bottom: 15,right: 10),
                    padding: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius:
                        BorderRadius.all(Radius.circular(12))),
                    child: TextFormField(
                      enabled: true,
                      controller: location,
                      validator: (string){
                        if(string == "") return "Please enter crime location in details";
                        return null;
                      },
                      style: TextStyle(color: Colors.black,),
                      decoration: InputDecoration(
                          labelText: "Crime Location and Address",
                          labelStyle: TextStyle(color: Colors.black26),
                          fillColor: Colors.black),
                    )),
                Container(

                    width: MediaQuery.of(context).size.width * 0.9,
                    margin: EdgeInsets.only(bottom: 15,right: 10),
                    padding: EdgeInsets.only(bottom: 10),
                    decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius:
                        BorderRadius.all(Radius.circular(12))),
                    child: TextFormField(
                      enabled: true,
                      controller: crimeDesc,
                      validator: (string){
                        if(string == "") return "Please enter crime incident";
                        return null;
                      },
                      style: TextStyle(color: Colors.black,),
                      maxLines: 8,
                      decoration: InputDecoration(
                          labelText: "Crime Description",
                          labelStyle: TextStyle(color: Colors.black26),
                          fillColor: Colors.black26),
                    )),
                locprocessing? Container(
                    margin: EdgeInsets.only(top:20),
                    width:20, child: LinearProgressIndicator(backgroundColor: Colors.white,value: 5,)):Container(),
         Container(
        alignment: Alignment.center,
        margin: EdgeInsets.only(top: 30),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          Text("Copy Tracking Code: $crimeCode"),
          IconButton(icon:Icon(Icons.copy), onPressed: () {
            FlutterClipboard.copy(crimeCode);
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Code Copied"),backgroundColor: Colors.green,));
          },)
        ],)
        ),
                Container(
                    width: 190,
                    margin: EdgeInsets.only(top: 40),
                    child:
                Column(
                  children: [
                    Container(child: Text("${currentLocation.text}")),
                    TextButton(
                      // color: Colors.orange[500],
                      child: Row(
                          children: [
                            Icon(Icons.location_searching_sharp),
                            Text("Get My Location"),
                          ]
                      ),
                      onPressed: () async {
                        setState((){
                          locprocessing = true;
                        });
                        if (formKey.currentState!.validate())  {
                          currentLocation.text = await EngineRoom.getLocAddress();
                          setState(() {
                            locprocessing = false;
                          });
                        } else
                        {

                          setState(() {
                            _autoValidate = true;
                            locprocessing = false;
                          });
                        }
                      },
                    )
                  ],
                )

                ),
                Container(margin: EdgeInsets.all(50),
                  child: Text("Upload Pictures of Location")
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [

                      Container(
                        height: 100,
                        width: 100,
                        child: InkWell(
                          child:_image.path != '' ? Image.file(_image):Placeholder(),
                          onTap: ()=>{
                          selectImage(1)
                          },
                        )
                      ),
                      Container(
                        height: 100,
                        width: 100,
                        child: InkWell(
                          child:_image2.path != '' ? Image.file(_image2):Placeholder(),
                          onTap: ()=>{
                          selectImage(2)
                          },
                        )
                      ),
                      Container(
                        height: 100,
                        width: 100,
                        child: InkWell(
                          child:_image3.path != '' ? Image.file(_image3):Placeholder(),
                          onTap: ()=>{
                          selectImage(3)
                          },
                        )
                      ),

                    ]
                  )
                ),

                Container(
                    width: 200,
                    margin: EdgeInsets.only(top: 40),
                    child: processing
                        ? Container(width:40, child: CircularProgressIndicator(backgroundColor: Colors.white,value: 5,)):
                    ElevatedButton(
                      // color: Colors.orange[500],
                      onPressed: () {
                        setState((){
                          processing = true;
                        });
                        if (formKey.currentState!.validate() && lga.text != "" && currentLocation.text != "") {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Saving data")));

                          setState(() {
                            processing = false;
                          });
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Saved")));
                          saveData().then((value) => Future.delayed(Duration(seconds: 2),()=>Navigator.push(context, MaterialPageRoute(builder: (context) => MyApp()))));

                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Please ensure all fields are filled")));
                          setState(() {
                            _autoValidate = true;
                            processing = false;
                          });
                        }
                      },
                      child: Text("Submit"),
                    )),
              ]
            )
        )
      ],
    );
  }


  Future<Crime> saveData() async{


      Crime crime = new Crime.fromMap({
        'crimeType': crimeType.text,
        'crimeDescription': crimeDesc.text,
        'crimeLocation': location.text,
        'crimeState': _stateLoc,
        'crimeLga': lga.text,
        'crimeCode': crimeCode,
        'reporterLocation':currentLocation.text,
        'dateCreated': DateTime.now().toString(),
        'img': _image.path,
        'img2': _image2.path,
        'img3': _image3.path,
        'reportedBy': widget.user?.email ?? "guest",
      });
      // print(crime.cName);
      return await DbProvider.db.insertDb(crime) as Crime;
  }

  selectImage(im) async {
    final ImagePicker _picker = ImagePicker();
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery );
    setState(() {
      if (image != null) {
        switch(im){
          case 1:
        _image = File(image.path);
        break;
          case 2:
        _image2 = File(image.path);
            break;
         case 3:
        _image3 = File(image.path);
            break;
        }
      } else {
        print('No image selected.');
      }
    });
  }

}
