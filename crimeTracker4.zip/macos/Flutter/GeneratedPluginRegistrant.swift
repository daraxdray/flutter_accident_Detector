//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import menubar
import window_size

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  MenubarPlugin.register(with: registry.registrar(forPlugin: "MenubarPlugin"))
  WindowSizePlugin.register(with: registry.registrar(forPlugin: "WindowSizePlugin"))
}
