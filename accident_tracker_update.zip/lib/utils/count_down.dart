import 'dart:async';

import 'package:flutter/material.dart';



class CountDownTime extends StatefulWidget {
  final int? duration;

  final Widget? initWidget;
  final Widget? countedWidget;
  final TextStyle? counterTextStyle;
  final String? btnMsg;
  final dynamic onStart;
  final dynamic onFinish;
  const CountDownTime({Key? key, this.initWidget, this.duration, this.countedWidget, this.onStart, this.onFinish, this.counterTextStyle, this.btnMsg}) : super(key: key);

  @override
  _CountDownTimeState createState() => _CountDownTimeState();
}


class _CountDownTimeState extends State<CountDownTime> {

  int _counter = 30;
  Timer? _timer;
  int _countStatus = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _countStatus = 0;
  }


  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }


  void _startTimer(){
    widget.onStart();
    _counter = widget.duration ?? 30;
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(oneSec, (Timer timer){
      if(_counter == 0){
        setState(() {
          timer.cancel();
          _countStatus = 0;
          widget.onFinish;
        });
      }else{
        setState(() {
          _counter--;
          _countStatus = 1;
        });
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
            child: _countStatus == 0 ? widget.initWidget:
            widget.countedWidget
        ),
        SizedBox(
          child: _countStatus == 1 ? Text("$_counter", style: widget.counterTextStyle ?? const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)):
          TextButton(child: Text(widget.btnMsg ?? "Start", style: const TextStyle(color: Colors.black, fontWeight: FontWeight.normal),), onPressed:
              ()=>_startTimer(),)

        )
      ]
    );
  }
}
